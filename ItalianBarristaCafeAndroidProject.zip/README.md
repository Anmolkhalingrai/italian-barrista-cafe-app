# Italian Barrista Café Android starter project

This is an Android Studio project for a basic installable app shell with an offline menu demo.

## Included
- English/Arabic language toggle
- Pickup and delivery selection
- Sample menu in OMR
- Cart and demo checkout
- 5% tax-included note

## Important limitations
- The demo menu includes only six sample items, not the full café PDF menu.
- It uses emoji placeholders rather than the original menu photos.
- Checkout is a local demo only. It does not send orders, accept payments, or store orders on a restaurant server.
- This project is source code, not a prebuilt APK.

## Build the APK
1. Install Android Studio and the Android SDK (Android Developers: https://developer.android.com/studio).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output path, typically `app/build/outputs/apk/debug/app-debug.apk`.

To distribute a release APK, use **Build > Generate Signed Bundle / APK** and protect the signing key. See https://developer.android.com/studio/publish/app-signing.
